-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 10, 2017 at 08:14 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30
GRANT ALL PRIVILEGES ON *.* TO 'admin'@'localhost' IDENTIFIED BY PASSWORD '*00A51F3F48415C7D4E8908980D443C29C69B60C9' WITH GRANT OPTION;

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `HospitalAppointment`
--
CREATE DATABASE HospitalAppointment;
-- --------------------------------------------------------

--
-- Table structure for table `Admin`
--
DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `PastApp`(IN `Bran` VARCHAR(20))
    NO SQL
SELECT * FROM Appointment WHERE (Branch=Bran OR Bran='ALL') AND Dat<CURRENT_TIME ORDER BY Dat ASC$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `FutureApp`(IN `Bran` VARCHAR(20))
    NO SQL
SELECT * FROM Appointment WHERE (Branch=Bran OR Bran='ALL') AND Dat>CURRENT_TIME ORDER BY Dat ASC$$
DELIMITER ;

CREATE TABLE `Admin` (
  `Uname` varchar(10) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `Passwd` varchar(30) CHARACTER SET ascii COLLATE ascii_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Admin`
--

INSERT INTO `Admin` (`Uname`, `Passwd`) VALUES
('admin1', '1234567');

-- --------------------------------------------------------

--
-- Table structure for table `Appointment`
--

CREATE TABLE `Appointment` (
  `App_ID` int(11) NOT NULL ,
  `DocID` int(11) NOT NULL,
  `PatID` int(11) NOT NULL,
  `Dat` datetime NOT NULL,
  `Branch` varchar(20) CHARACTER SET ascii COLLATE ascii_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Appointment`
--

INSERT INTO `Appointment` (`App_ID`,`DocID`, `PatID`, `Dat`, `Branch`) VALUES
(1,4, 1, '2017-05-10 00:00:00', 'Oncology'),
(2,4, 1, '2017-05-11 00:00:00', 'Endocrinology'),
(3,5, 2, '2017-05-10 00:00:00', 'Gastrology');

-- --------------------------------------------------------

--
-- Table structure for table `Branch`
--

CREATE TABLE `Branch` (
  `Bname` varchar(30) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `BID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Branch`
--

INSERT INTO `Branch` (`Bname`, `BID`) VALUES
('Proctology', 8),
('Gastrology', 9),
('Oncology', 10);

-- --------------------------------------------------------

--
-- Table structure for table `Doctor`
--

CREATE TABLE `Doctor` (
  `Id` int(11) NOT NULL,
  `DName` varchar(20) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `Branch` varchar(20) CHARACTER SET ascii COLLATE ascii_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Doctor`
--

INSERT INTO `Doctor` (`Id`, `DName`, `Branch`) VALUES
(4, 'Susanna', 'Gastrology'),
(5, 'Michael', 'Oncology');

-- --------------------------------------------------------

--
-- Table structure for table `Patient`
--

CREATE TABLE `Patient` (
  `ID` int(11) NOT NULL,
  `Name` varchar(20) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `Passwd` varchar(20) CHARACTER SET ascii COLLATE ascii_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Patient`
--

INSERT INTO `Patient` (`ID`, `Name`, `Passwd`) VALUES
(1, 'Alice', '12345'),
(2, 'bob', '123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Appointment`
--
ALTER TABLE `Appointment`
  ADD PRIMARY KEY (`App_ID`);

--
-- Indexes for table `Branch`
--
ALTER TABLE `Branch`
  ADD PRIMARY KEY (`BID`);

--
-- Indexes for table `Doctor`
--
ALTER TABLE `Doctor`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `Patient`
--
ALTER TABLE `Patient`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--
--
-- AUTO_INCREMENT for table `Appointment`
--
ALTER TABLE `Appointment`
  MODIFY `App_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `Branch`
--
ALTER TABLE `Branch`
  MODIFY `BID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `Doctor`
--
ALTER TABLE `Doctor`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Patient`
--
ALTER TABLE `Patient`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
