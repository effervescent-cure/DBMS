<html>
<body>
<?php
include('connection.php');
session_start();
$name=$_GET['docName'];
$sql="SELECT * FROM Doctor where DName='$name'";
$result=$conn->query($sql);
$row=$result->fetch_assoc();

?>							
                        <table border = 1>
                       			 
                            
                            <th>Name</th>
                            <th>Branch</th>
							<tr>
                            <td><?php echo $row["DName"]; ?></td>
                            <td><?php echo $row["Branch"]; ?></td>
                             
                             
                        </tr>
                        </table>

<p>New field values </p>
<form action="editor.php?" method="post">

         <p>Name: <input type="text" name="DName" value="<?php echo "";?>" required/></p>
         <p>Branch <input type="text" name="BName" value="<?php echo "";?>" required/></p>
         <input type="hidden" name="old1" value="<?php echo $row["DName"];?>" />
         <input type="hidden" name="old2" value="<?php echo $row["Branch"];?>" />
         <input type="submit" value="Change"/>
        </form>



<p><a href="adminhome.php"> Go Back </a></p>
</body>

</html>