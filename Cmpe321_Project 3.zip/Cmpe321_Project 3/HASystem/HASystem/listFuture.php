<html>
<body>
    <?php
   
    include ("connection.php");
    session_start();
    $bran=$_POST['branch'];
    $sql="CALL FutureApp('$bran')";
    $result=$conn->query($sql);

    if($result->num_rows<1){
        echo "No future appointment found!";
    }else{
                    ?>
                    <table border = 1>
                        <tr>
                            
                            <th>Doctor Name</th>
                            <th>Branch</th>
                            <th>Patient Name</th>
                            <th>Date</th>
                            
                           
                         
                    <?php

                    // output data of each row
                    while($row = $result->fetch_assoc()) {
                        ?>
                        <tr>
                            <td><?php echo $row["DocID"]; ?></td>
                            <td><?php echo $row["Branch"]; ?></td>
                            <td><?php echo $row["PatID"]; ?></td>
                            <td><?php echo $row["Dat"]; ?></td>
                            
                        </tr>
                        <?php
                    }

                    ?>
                    </table>
                    <?php
                } 
            
           

    $conn->close();
?>
</body>
<p><a href="adminhome.php"> Back </a></p>
</html>