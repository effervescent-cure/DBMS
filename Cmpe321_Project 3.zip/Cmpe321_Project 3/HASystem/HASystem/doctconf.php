<html>

	<body>
	<?php

	include('connection.php');
	session_start();
	$name=$_POST['name'];
	$branch=$_POST['branch'];
	$sql="SELECT DName, Branch FROM Doctor WHERE DName='$name' AND Branch='$branch'";
	$result=$conn->query($sql);
	if($result->num_rows<1){
		$sql="SELECT Bname FROM Branch WHERE Bname='$branch'";
		$result=$conn->query($sql);
		if($result->num_rows>0){
			$sql="INSERT INTO Doctor (DName,Branch) VALUES ('$name','$branch')";
			$conn->query($sql);
			echo "Doctor Inserted";
		}else{
			echo "Branch does not exist in this hospital.";
		}
		
	}else{

		echo "Doctor with this branch already exists.";
	}

	$conn->close();
	?>
	
	</body>
<p><a href="adminhome.php"> Back </a></p>
</html>