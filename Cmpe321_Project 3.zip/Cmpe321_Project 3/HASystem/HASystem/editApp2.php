<html>
<body>
<?php
include('connection.php');
session_start();
$appId=$_GET['App_ID'];
$username = $_SESSION['login'];
$sql="SELECT * FROM Branch ORDER BY Bname ASC";
    
    $result=$conn->query($sql);
    if($result->num_rows<1){
        echo "No branch found!";
    }else{
                    ?>
                    <table border = 1>
                        <tr>
                            
                            <th>Branch Name</th>
                           
                            <th>Option </th>
                            
                           
                         
                    <?php

                    // output data of each row
                    while($row = $result->fetch_assoc()) {
                        
                        ?>
                        <tr>
                            <td><?php echo $row["Bname"]; ?></td>
                            
                            
                             <?php
                            echo "<td><a href=editApp3.php?Bname=";
                            echo $row["Bname"];
                            echo "&App_ID=";
                            echo $appId;
                            echo ">CHOOSE</a></td>";
                            ?>
                
                        </tr>
                        <?php
                    }

                    ?>
                    </table>
                    <?php
                } 
            
           

    $conn->close();
?>


<p><a href="patienthome.php"> Go Back </a></p>
</body>

</html>