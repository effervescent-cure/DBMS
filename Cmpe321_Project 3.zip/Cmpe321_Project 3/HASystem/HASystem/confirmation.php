<html>

	<body>
	<?php

	include('connection.php');
	session_start();
	$username=$_POST['username'];
	$password=$_POST['password'];

	
	if($username!= NULL and $username!=""){
	$sql="INSERT INTO Patient (Name,Passwd) VALUES ('$username','$password')";
	$conn->query($sql);
	if($conn->connect_error){
		echo "Error";
	}else{
		echo "Inserted \r\n";
	}
}else{
	echo "Key cannot be null";
}
	$conn->close();
	?>
	
	</body>
<p><a href="index.php"> Back </a></p>
</html>