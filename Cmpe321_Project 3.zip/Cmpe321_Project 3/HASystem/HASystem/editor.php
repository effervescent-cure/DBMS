<html>
<body>
<?php
include('connection.php');
session_start();
$newname=$_POST['DName'];
$newdept=$_POST['BName'];
$oldn=$_POST['old1'];
$oldd=$_POST['old2'];
$sql="SELECT BName FROM Branch WHERE BName='$newdept'";
$result=$conn->query($sql);
if($result->num_rows==0){
  $sql="INSERT INTO Branch (BName) VALUES ('$newdept')";
  $conn->query($sql);
}
$sql="UPDATE Doctor SET Name='$newname', Branch='$newdept' WHERE Name='$oldn' AND Branch='$oldd'";
$conn->query($sql);
echo "Updated";
?>	
<p><a href="adminhome.php"> Go home </a></p>
</body>

</html>