<html>
<body>
    <?php
   
    include ("connection.php");
    session_start();
    $sql="SELECT * FROM Branch ORDER BY Bname ASC";
    
    $result=$conn->query($sql);
    if($result->num_rows<1){
        echo "No branch found!";
    }else{
                    ?>
                    <table border = 1>
                        <tr>
                            
                            <th>Branch Name</th>
                           
                            <th>Option </th>
                            
                           
                         
                    <?php

                    // output data of each row
                    while($row = $result->fetch_assoc()) {
                        
                        ?>
                        <tr>
                            <td><?php echo $row["Bname"]; ?></td>
                            
                            
                             <?php
                            echo "<td><a href=takeapp2.php?Bname=";
                            echo $row["Bname"];
                            echo ">CHOOSE</a></td>";
                            ?>
                
                        </tr>
                        <?php
                    }

                    ?>
                    </table>
                    <?php
                } 
            
           

    $conn->close();
?>
</body>
<p><a href="patienthome.php"> Back </a></p>
</html>