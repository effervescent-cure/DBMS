<html>
<body>
<?php
include("connection.php");

session_start();
$_SESSION["login"] = 0;
$username=$_POST['username'];
$password=$_POST['password'];
$username=mysqli_real_escape_string($conn,$username);
$password=mysqli_real_escape_string($conn,$password);
$sql="SELECT * FROM Patient WHERE Passwd='$password' AND Name='$username'";

	if(!$conn->query($sql)->num_rows>0){
		$sql="SELECT * FROM Admin WHERE Passwd='$password' AND Uname='$username'";
		if(!$conn->query($sql)->num_rows>0){
			echo "Mismatch username and password";
			
			echo "<p>";
			echo "<a href=";
			echo "index.php>";
			echo "Go back";
			echo "</a>";
			echo "</p>";

		}else{
			$_SESSION["login"] = $username;
			header('Location: adminhome.php');  
			exit();
		}
		
	}else{
		echo "Welcome";
		$_SESSION["login"] = $username;
		header('Location: patienthome.php');
		exit();
		
	}
	
?>


</body>

</html>