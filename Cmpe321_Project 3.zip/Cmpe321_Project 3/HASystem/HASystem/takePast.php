<html>
<body>
<?php
include("connection.php");
session_start();
?>
<form action="listPast.php" method="post">
         <p>Branch: <input type="text" name="branch" required /></p>
        
         <input type="submit" value="Next"/>
        </form>
<a href="adminhome.php"> Go back </a>
</body>
 </html>