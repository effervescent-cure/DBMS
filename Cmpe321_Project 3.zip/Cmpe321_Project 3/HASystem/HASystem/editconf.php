<html>
<body>
<?php
include("connection.php");
session_start();
$username = $_SESSION['login'];
$DocID= $_GET['DocID'];
$appId=$_GET['App_ID'];
$dayy = $_POST["day"];
$monthh = $_POST["month"];
$yearr = $_POST["year"];
$hourr = $_POST["hour"];
$minutee = $_POST["minute"];
//$s = ''.$dayy.'-'.$monthh.'-'.$yearr.' '.$hourr.':'.$minutee.':'.'00';  //06/10/2011 19:00:02';
//echo $s;
$yearr = $yearr - 2000;
$appdate = $yearr.$monthh.$dayy.$hourr.$minutee.'00';

//$time = strtotime($s);
//$appdate = date('d/M/Y H:i:s', $time);
//$appdate = DateTime::createFromFormat('Y/M/d H:i:s', $s);
//$appdate-> DateTime::getTimestamp();
$sql="DELETE FROM Appointment where App_ID='$appId'";
$conn->query($sql);

$sql="SELECT * FROM Appointment where DocID='$DocID' AND Dat ='$appdate'";
        $result=$conn->query($sql);
        
        if($result->num_rows>0){
            
        ?>
        <p><?php echo "There exist an Appointment. Please chose another time"; ?> </p>
        <p><a href="patienthome.php"> Back </a></p>
        
        <?php    
        } else {
            $sql="SELECT * FROM Patient where Name='$username'";
            $result=$conn->query($sql);
        	$row = $result->fetch_assoc();
        	$PatID = $row['ID'];
        	$sql="SELECT * FROM Doctor where Id='$DocID'";
            $result=$conn->query($sql);
        	$row = $result->fetch_assoc();
        	$Branch = $row['Branch'];
        	$sql="INSERT INTO Appointment (DocID,PatID,Dat,Branch) VALUES ('$DocID','$PatID','$appdate','$Branch')";
        	$conn->query($sql);
			echo "Appointment Inserted";
        }
	$conn->close();
?>

<p><a href="patienthome.php"> Home </a></p>
</body>

</html>