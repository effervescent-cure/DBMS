<html>

	<body>
	<?php

	include('connection.php');
	session_start();
	$DName=$_GET['DName'];
	$Branch=$_GET['Branch'];
    $username=$_SESSION['login'];
    $DocId = "";
    $appdate ="000000000000000000000";
    $sql="SELECT * FROM Doctor where DName='$DName'";
        $result=$conn->query($sql);
        if($result->num_rows>0){
            $row = $result->fetch_assoc();
            $DocID = $row["Id"];
        } 

	if($_SERVER["REQUEST_METHOD"]=="POST"){
		$dayy = $_POST["day"];
		$monthh = $_POST["month"];
		$yearr = $_POST["year"];
		$hourr = $_POST["hour"];
		$minutee = $_POST["minute"];
		$s = '06/10/2011 19:00:02';
        $appdate = strtotime($s);

        $sql="SELECT * FROM Doctor where DName='$DName'";
        $result=$conn->query($sql);
        
        if($result->num_rows>0){
            $row = $result->fetch_assoc();
            $DocID = $row["Id"];
        } 

	}
	
	?>
	
	<p><b>Please Fill Day and Month </b></p>
        <form action="appconf.php?<?php echo "DocID=".$DocID;?>" method="post">
        <tr>
        <td>Time:</td> 
        <td>
            <select name="hour">
                <option value="08"> 8 </option>
                <option value="09"> 9 </option>
                <option value="10"> 10 </option>
                <option value="11"> 11</option>
                <option value="12"> 12 </option>
                <option value="13"> 13 </option>
                <option value="14"> 14 </option>
                <option value="15"> 15 </option>
                <option value="16"> 16 </option>
            </select>                   
 
            <select name="minute">
                <option value="00"> 00 </option>
                <option value="05"> 05 </option>
                <option value="10"> 10 </option>
                <option value="15"> 15 </option>
                <option value="20"> 20</option>
                <option value="25"> 25 </option>
                <option value="30"> 30 </option>
                <option value="35"> 35 </option>
                <option value="40"> 40 </option>
                <option value="45"> 45 </option>
                <option value="50"> 50 </option>
                <option value="55"> 55 </option>
            </select>                   
                               
        </td>
      </tr>
        <tr>
        <td>Date:</td> 
        <td>
            
            <select name="day">
                <option value="01"> 1 </option>
                <option value="02"> 2 </option>
                <option value="03"> 3 </option>
                <option value="04"> 4</option>
                <option value="05"> 5 </option>
                <option value="06"> 6 </option>
                <option value="07"> 7 </option>
                <option value="08"> 8 </option>
                <option value="09"> 9 </option>
                <option value="10"> 10 </option>
                <option value="11"> 11</option>
                <option value="12"> 12 </option>
                <option value="13"> 13 </option>
                <option value="14"> 14</option>
                <option value="15"> 15 </option>
                <option value="16"> 16</option>
                <option value="17"> 17 </option>
                <option value="18"> 18 </option>
                <option value="19"> 19 </option>
                <option value="20"> 20 </option>
                <option value="21"> 21 </option>
                <option value="22"> 22 </option>
                <option value="23"> 23 </option>
                <option value="24"> 24 </option>
                <option value="26"> 26 </option>
                <option value="27"> 27 </option>
                <option value="28"> 28 </option>
                <option value="29"> 29 </option>
                <option value="30"> 30 </option>
            </select>

            <select name="month">
                <option value="01"> 1 </option>
                <option value="02"> 2 </option>
                <option value="03"> 3 </option>
                <option value="04"> 4</option>
                <option value="05"> 5 </option>
                <option value="06"> 6 </option>
                <option value="07"> 7 </option>
                <option value="08"> 8 </option>
                <option value="09"> 9 </option>
                <option value="10"> 10 </option>
                <option value="11"> 11</option>
                <option value="12"> 12 </option>
            </select>
        
            <select name="year">
                <option value="2017"> 2017 </option>
            </select>
        </td>
        </tr>
    

<input type="submit" value="appointment"/>
</form>            
              
	
	</body>
<p><a href="patienthome.php"> Back </a></p>
</html>