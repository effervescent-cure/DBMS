<html>
<body>
<?php
include('connection.php');
session_start();
$username = $_SESSION['login'];

$sql="SELECT * FROM Patient WHERE Name='$username'";
$result=$conn->query($sql);

if($result->num_rows>0){
  
  $row = $result->fetch_assoc();
  $PatID = $row['ID'];
  $sql="SELECT * FROM Appointment WHERE PatID='$PatID'AND Dat>CURRENT_TIME";
  $result=$conn->query($sql);
    if($result->num_rows<1){
        echo "No appointment found!";
    }else{
                    ?>
                    <table border = 1>
                        <tr>
                            
                            <th>Patient Name</th>
                            <th>Branch</th>
                            <th>Date Time</th>
                            
                           
                         
                    <?php

                    // output data of each row
                    while($row = $result->fetch_assoc()) {
                        ?>
                        <tr>
                            <td><?php echo $username; ?></td>
                            <td><?php echo $row["Branch"]; ?></td>
                            <td><?php echo $row["Dat"]; ?></td>
                            
        
                             <?php
                            echo "<td><a href=editApp2.php?App_ID=";
                            echo $row["App_ID"];                          
                            echo ">EDIT</a></td>";
                            ?>
                            
                        </tr>
                        <?php
                    }

                    ?>
                    </table>
                    <?php
                } 
            
  }
    $conn->close();
?>
<p><a href="patienthome.php"> Go Back </a></p>
</body>
</html>