<html>
<body>
<?php
include('connection.php');
session_start();
$name=$_GET['docName'];
$sql="DELETE FROM Doctor WHERE name='$name'";
$result=$conn->query($sql);
$conn->query($sql);
echo "Deletion finished";
?>






<p><a href="adminhome.php"> Go Back </a></p>
</body>

</html>