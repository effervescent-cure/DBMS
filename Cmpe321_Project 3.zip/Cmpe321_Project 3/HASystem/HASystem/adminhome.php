<html>
	<body>
	<?php
	include ('connection.php');
	session_start();
	?>
	<p> Which choice you want to make? </p>
	<p><a href="addDoctor.php"> Add a doctor</a> </p>
	<p><a href="addBranch.php"> Add a branch</a></p>
	<p><a href="listDoctors.php"> List Doctors</a></p>
	<p><a href="listBranches.php"> List Branches</a></p>
	<p><a href="takePast.php"> List Past Appointments</a></p>
	<p><a href="takeFuture.php"> List Future Appointments</a></p>
	</body>
<form action="logout.php" method="post">
<input type="submit" value="Logout"/>
</form>


</html>