<html>
<body>
<?php
session_start();
session_destroy();
echo 'You have been logged out'; 
?>

</body>
<p><a href="index.php">Go back</a></p>
</html>