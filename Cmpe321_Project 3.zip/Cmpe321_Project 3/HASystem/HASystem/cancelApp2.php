<html>
<body>
<?php
include('connection.php');
session_start();
$AppID=$_GET['App_ID'];



$sql="DELETE FROM Appointment WHERE App_ID='$AppID'";
$result=$conn->query($sql);
$conn->query($sql);
echo "Appointment is canceled.";
?>


<p><a href="patienthome.php"> Go Back </a></p>
</body>

</html>