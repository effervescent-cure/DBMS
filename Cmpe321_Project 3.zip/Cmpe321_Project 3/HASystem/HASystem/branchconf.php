<html>

	<body>
	<?php

	include('connection.php');
	session_start();
	$bname=$_POST['branch'];
	$sql="SELECT Bname FROM Branch WHERE Bname='$bname'";
	$result=$conn->query($sql);
	
	$temp=$result->num_rows;
	if($temp<1){

	$sql="INSERT INTO Branch (Bname) VALUES ('$bname')";
	$conn->query($sql);
	
echo "Insertion completed successfully.";
}else{
	echo "Branch already exists.";
}
	$conn->close();
	?>
	
	</body>
<p><a href="adminhome.php"> Back </a></p>
</html>