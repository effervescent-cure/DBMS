<html>
<body>
<?php
include('connection.php');
session_start();
$newb=$_POST['branch'];
$oldb=$_POST['oldbr'];
$sql="SELECT Bname FROM Branch WHERE Bname='$newb'";
$result=$conn->query($sql);
if($result->num_rows==1){
  echo "Branch already exists";
}else{
  $sql="UPDATE Branch SET Bname='$newb' WHERE Bname='$oldb'";
  $conn->query($sql);
  $sql="UPDATE Doctor SET Branch='$newb' WHERE Branch='$oldb'";
  $conn->query($sql);
  echo "Branch updated";
}

?>	
<p><a href="adminhome.php"> Go home </a></p>
</body>

</html>