<html>
<body>
    <?php
   
    include ("connection.php");
    session_start();
   
    $sql="SELECT DName, Branch FROM Doctor";
    $result=$conn->query($sql);
    if($result->num_rows<1){
        echo "No doctors found!";
    }else{
                    ?>
                    <table border = 1>
                        <tr>
                            
                            <th>Name</th>
                            <th>Branch</th>
                            <th>Option 1</th>
                            <th>Option 2</th>
                           
                         
                    <?php

                    // output data of each row
                    while($row = $result->fetch_assoc()) {
                        ?>
                        <tr>
                            <td><?php echo $row["DName"]; ?></td>
                            <td><?php echo $row["Branch"]; ?></td>
                             <?php
                            echo "<td><a href=editDoctor.php?docName=";
                            echo $row["DName"];
                            echo ">EDIT</a></td>";
                            echo $row["DName"];
                            ?>
                             <?php
                            echo "<td><a href=deleteDoctor.php?docName=";
                            echo $row["DName"];
                            echo ">DELETE</a></td>";
                            ?>
                            
                        </tr>
                        <?php
                    }

                    ?>
                    </table>
                    <?php
                } 
            
           

    $conn->close();
?>
</body>
<p><a href="adminhome.php"> Back </a></p>
</html>