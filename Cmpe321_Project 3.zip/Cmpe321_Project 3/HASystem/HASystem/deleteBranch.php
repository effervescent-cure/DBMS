<html>
<body>
<?php
include('connection.php');
session_start();
$id=$_GET['bname'];

$sql="SELECT * FROM Appointment WHERE Branch='$id' AND Dat>CURRENT_TIME";
$result=$conn->query($sql);

if($result->num_rows==0){
  $conn->query($sql);
  $sql="SELECT * FROM Doctor WHERE Branch='$id'";
  $result=$conn->query($sql);
  if($result->num_rows==0){
    $sql="DELETE FROM Appointment WHERE Branch='$id' AND Dat>CURRENT_TIME";
    $conn->query($sql);
    $sql="DELETE FROM Branch WHERE Bname='$id'";
    $conn->query($sql);
  }else{
    echo "Doctors exist and cannot be deleted";
  }

 

  $conn->query($sql);
  echo "Deletion finished \r\n";
}else{
  echo "Appointments exist and therefore cannot be deleted.";
}
?>






<p><a href="adminhome.php"> Go Back </a></p>
</body>

</html>