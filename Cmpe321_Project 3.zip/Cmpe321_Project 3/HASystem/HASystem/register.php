<html>
	<body>


	<?php

		include('connection.php');
                session_start();

	?>
 		<form action="confirmation.php" method="post">
         <p>Username: <input type="text" name="username" required/></p>
         <p>Password: <input type="text" name="password" required/></p>
         
        
         <input type="submit" value="Sign Up"/>
        </form>
<?php

$conn->close();
?>

	</body>


</html>