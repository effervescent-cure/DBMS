<html>
<body>
<?php
include('connection.php');
session_start();
$bname=$_GET['Bname'];
$appId=$_GET['App_ID'];
$username = $_SESSION['login'];
$sql="SELECT * FROM Doctor where Branch='$bname'";
$result=$conn->query($sql);
						
if($result->num_rows<1){
    echo "No doctor found!";
}else{
            ?>
            <table border = 1>
               
                            
                    <th>Doctor Name</th>
                    <th> Option</th>

                    <?php

                    // output data of each row
                    while($row = $result->fetch_assoc()) {
                        
                        ?>
                        <tr>
                            <td><?php echo $row["DName"]; ?></td>
                            
                            
                             <?php
                            echo "<td><a href=editApp4.php?DName=";
                            echo $row["DName"];
                            echo "&Branch=";
                            echo $row["Branch"];
                            echo "&App_ID=";
                            echo $appId;
                            echo ">CHOOSE</a></td>";
                            ?>
                
                        </tr>
                        <?php
                    }

                    ?>
                    </table>
                    <?php
                } 
            
           

    $conn->close();
?>
</body>
<p><a href="takeapp.php"> Back </a></p>
</html>