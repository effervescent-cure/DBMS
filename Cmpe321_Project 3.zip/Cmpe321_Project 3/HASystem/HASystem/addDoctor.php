<html>
	<body>

	<?php

		include('connection.php');
		session_start();

	?>
 	 <form action="doctconf.php" method="post">
         <p>Name: <input type="text" name="name" required /></p>
         <p>Branch: <input type="text" name="branch" required /></p>
         <input type="submit" value="Add"/>
        </form>
<?php

$conn->close();
?>


	</body>


</html>