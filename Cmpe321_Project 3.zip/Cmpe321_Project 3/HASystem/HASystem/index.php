<html>
<body>

<?php

include("connection.php");
session_start();
$_SESSION["login"] = 0;
echo "Login status: ".$_SESSION["login"];

?>
<form action="homepage.php" method="post">
         <p>Username: <input type="text" name="username" required/></p>
         <p>Password: <input type="password" name="password" required/></p>
         <input type="submit" value="Login"/>
        </form>
<form action="register.php" method="post">
<input type="submit" value="Register"/>
</form>
        

</body>
</html>