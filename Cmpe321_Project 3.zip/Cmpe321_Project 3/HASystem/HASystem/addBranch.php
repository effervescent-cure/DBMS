<html>

<body>

<?php

include ('connection.php');
session_start();
?>
<form action="branchconf.php" method="post">
         <p>Branch Name: <input type="text" name="branch" required /></p>
         
         <input type="submit" value="Next"/>
</form>

</body>



<p> <a href="adminhome.php"> Go back </a>

</html>