<html>
	<body>
	<?php
	include ("connection.php");
	session_start();
	?>
	<p> Which choice you want to make? </p>
	<p><a href="takeapp.php"> Take Appointment </a></p>
	<p><a href="editapp.php"> Edit Appointment</a></p>
	<p><a href="cancelapp.php"> Cancel Appointment</a></p>
	</body>

<form action="logout.php" method="post">
<input type="submit" value="Logout"/>
</form>

</html>