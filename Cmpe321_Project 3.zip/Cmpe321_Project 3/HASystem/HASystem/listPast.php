<html>
<body>
    <?php
   
    include ("connection.php");
    session_start();
    $bran=$_POST['branch'];
    $sql="CALL PastApp('$bran')";
    $result=$conn->query($sql);

    if($result->num_rows<1){
        echo "No past appointment found!";
    }else{
                    ?>
                    <table border = 1>
                        <tr>
                            
                            <th>Doctor Name</th>
                            <th>Branch</th>
                            <th>Patient Name</th>
                            <th>Date</th>
                            
                           
                         
                    <?php

                    // output data of each row
                    while($row = $result->fetch_assoc()) {
                        $temp=$row["DocID"];
                        $temp1=$row["PatID"];
                     
                        $sql1="SELECT * FROM Doctor,Patient  WHERE Doctor.Id=$temp AND Patient.ID=$temp1";
                        
                        $result1=$conn->query($sql1);
                        echo "<pre>"; print_r($result1);
                        
                        
                       
                        ?>
                        <tr>
                            <td><?php echo $row["DocID"]; ?></td>
                            <td><?php echo $row["Branch"]; ?></td>
                            <td><?php echo $row["PatID"]; ?></td>
                            <td><?php echo $row["Dat"]; ?></td>
                            
                        </tr>
                        <?php
                    }

                    ?>
                    </table>
                    <?php
                } 
            
           

    $conn->close();
?>
</body>
<p><a href="adminhome.php"> Back </a></p>
</html>