<html>
<body>
<?php
include('connection.php');
session_start();
$name=$_GET['bname'];
$sql="SELECT * FROM Branch where Bname='$name'";
$result=$conn->query($sql);
$row=$result->fetch_assoc();


?>							<table border = 1>
                       			 
                            
                            <th>Branch Name</th>
                           
							<tr>
                            <td><?php echo $row["Bname"]; ?></td>
                           
                             
                        </tr>
                        </table>

<p>New field values </p>
<form action="editorBranch.php?" method="post">

         <p>Branch Name: <input type="text" name="branch" value="<?php echo "";?>" required/></p>
        
        
         
         <input type="hidden" name="oldbr" value="<?php echo $row['Bname'];?>"/>
        
         <input type="submit" value="Change"/>
        </form>



<p><a href="adminhome.php"> Go Back </a></p>
</body>

</html>