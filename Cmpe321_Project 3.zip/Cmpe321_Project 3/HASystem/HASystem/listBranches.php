<html>
<body>
    <?php
   
    include ("connection.php");
    session_start();
    $sql="SELECT * FROM Branch ORDER BY Bname ASC";
    
    $result=$conn->query($sql);
    if($result->num_rows<1){
        echo "No branch found!";
    }else{
                    ?>
                    <table border = 1>
                        <tr>
                            
                            <th>Branch Name</th>
                           
                            <th>Option 1</th>
                            <th>Option 2</th>
                           
                         
                    <?php

                    // output data of each row
                    while($row = $result->fetch_assoc()) {
                        
                        ?>
                        <tr>
                            <td><?php echo $row["Bname"]; ?></td>
                            
                            
                             <?php
                            echo "<td><a href=editBranch.php?bname=";
                            echo $row["Bname"];
                            echo ">EDIT</a></td>";
                            ?>
                             <?php
                            echo "<td><a href=deleteBranch.php?bname=";
                            echo $row["Bname"];
                            echo ">DELETE</a></td>";
                            ?>
                        </tr>
                        <?php
                    }

                    ?>
                    </table>
                    <?php
                } 
            
           

    $conn->close();
?>
</body>
<p><a href="adminhome.php"> Back </a></p>
</html>